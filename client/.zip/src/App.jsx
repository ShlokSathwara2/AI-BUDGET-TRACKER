import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import { Menu, X, Wallet, User, LogOut, Sun, Moon, Shield, Lock, CheckCircle, Brain, Eye } from 'lucide-react';
import { loadAllUserData, pushAllUserData, addTransactionAPI, updateTransactionAPI, deleteTransactionAPI, addBankAccountAPI, deleteBankAccountAPI, addPaymentReminderAPI, updatePaymentReminderAPI, deletePaymentReminderAPI } from './utils/api';

// ─── Shared data hook ─────────────────────────────────────────────────────────
const save = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch {} };
const load = (key, fallback) => {
  try { const r = localStorage.getItem(key); return r ? JSON.parse(r) : fallback; } catch { return fallback; }
};

function useAppData(user) {
  const uid = user?.id;
  const [transactions, _setTx]  = useState([]);
  const [bankAccounts, _setAcc] = useState([]);
  const [reminders,    _setRem] = useState([]);
  const [goals,        _setGoal] = useState([]);

  const txKey  = uid ? `transactions_${uid}`      : null;
  const accKey = uid ? `bank_accounts_${uid}`     : null;
  const remKey = uid ? `payment_reminders_${uid}` : null;
  const goalKey = uid ? `saving_goals_${uid}`     : null;

  useEffect(() => {
    if (!uid) { _setTx([]); _setAcc([]); _setRem([]); _setGoal([]); return; }
    _setTx(load(txKey,  []));
    _setAcc(load(accKey, []));
    _setRem(load(remKey, []));
    _setGoal(load(goalKey, []));
  }, [uid]);

  useEffect(() => {
    const fn = () => {
      if (document.visibilityState !== 'visible' || !uid) return;
      _setTx(load(txKey,  []));
      _setAcc(load(accKey, []));
      _setRem(load(remKey, []));
      _setGoal(load(goalKey, []));
    };
    document.addEventListener('visibilitychange', fn);
    return () => document.removeEventListener('visibilitychange', fn);
  }, [uid]);

  const setTransactions = (arr) => { const a = Array.isArray(arr)?arr:[]; _setTx(a); if(txKey) save(txKey,a); };
  const setBankAccounts = (arr) => { const a = Array.isArray(arr)?arr:[]; _setAcc(a); if(accKey) save(accKey,a); };
  const setReminders    = (arr) => { const a = Array.isArray(arr)?arr:[]; _setRem(a); if(remKey) save(remKey,a); };
  const setGoals        = (arr) => { const a = Array.isArray(arr)?arr:[]; _setGoal(a); if(goalKey) save(goalKey,a); };

  // ── Transaction actions ──
  const addTransaction = (newTx) => {
    if (!uid || !newTx) return null;
    const amount = parseFloat(newTx.amount) || 0;
    if (amount <= 0) return null;
    const tx = {
      ...newTx, user:uid,
      _id: `tx_${Date.now()}_${Math.random().toString(36).slice(2)}`,
      createdAt: new Date().toISOString(),
      date: newTx.date || new Date().toISOString(),
      amount,
      merchant:     newTx.merchant      || 'Unknown',
      description:  newTx.description   || '',
      category:     newTx.category      || 'Uncategorized',
      type:         newTx.type          || 'debit',
      paymentMethod:newTx.paymentMethod || 'cash',
    };
    const freshTx  = load(txKey,  []);
    const newArr   = [tx, ...freshTx];
    _setTx(newArr); if(txKey) save(txKey, newArr);

    if (tx.bankAccountId && tx.mode !== 'cash') {
      const change = tx.type === 'credit' ? amount : -amount;
      const freshAcc = load(accKey, []);
      const updAcc   = freshAcc.map(a => a?.id===tx.bankAccountId
        ? { ...a, balance: (typeof a.balance==='number'?a.balance:0) + change } : a);
      _setAcc(updAcc); if(accKey) save(accKey, updAcc);
    }
    return tx;
  };

  const updateTransaction = (upd) => {
    if (!uid) return;
    const arr = load(txKey,[]).map(t => t._id===upd._id ? {...t,...upd} : t);
    _setTx(arr); if(txKey) save(txKey,arr);
  };

  const deleteTransaction = (id) => {
    if (!uid) return;
    const arr = load(txKey,[]).filter(t => t._id!==id);
    _setTx(arr); if(txKey) save(txKey,arr);
  };

  // ── Bank account actions ──
  const addBankAccount = (acc) => {
    if (!uid) return;
    const obj = { ...acc, id: acc.id||`acc_${Date.now()}`, balance: acc.balance||0, createdAt: new Date().toISOString() };
    const arr = [...load(accKey,[]), obj];
    _setAcc(arr); if(accKey) save(accKey,arr);
    return obj;
  };

  const updateBankAccount = (id, changes) => {
    if (!uid) return;
    const arr = load(accKey,[]).map(a => a?.id===id ? {...a,...changes} : a);
    _setAcc(arr); if(accKey) save(accKey,arr);
  };

  const deleteBankAccount = (id) => {
    if (!uid) return;
    const arr = load(accKey,[]).filter(a => a?.id!==id);
    _setAcc(arr); if(accKey) save(accKey,arr);
  };

  // ── Reminder actions ──
  const addReminder = (r) => {
    if (!uid) return;
    const obj = { ...r, id: r.id||`rem_${Date.now()}`, completed:false, createdAt:new Date().toISOString() };
    const arr = [...load(remKey,[]), obj];
    _setRem(arr); if(remKey) save(remKey,arr);
    return obj;
  };

  const updateReminder = (id, changes) => {
    if (!uid) return;
    const arr = load(remKey,[]).map(r => r.id===id ? {...r,...changes} : r);
    _setRem(arr); if(remKey) save(remKey,arr);
  };

  const deleteReminder = (id) => {
    if (!uid) return;
    const arr = load(remKey,[]).filter(r => r.id!==id);
    _setRem(arr); if(remKey) save(remKey,arr);
  };

  /**
   * Auto-debit a reminder: creates debit tx, updates account balance, marks reminder paid.
   * Returns { success, insufficient, message, account, amount, reminder }
   */
  const autoDebitReminder = (reminder) => {
    if (!uid) return { success:false, message:'Not authenticated' };
    const amount = parseFloat(reminder.amount) || 0;
    if (amount <= 0) return { success:false, message:'Invalid amount' };
    const today = new Date();

    if (reminder.account && reminder.account !== 'cash') {
      const acc = load(accKey,[]).find(a => a?.id === reminder.account);
      if (acc && (acc.balance||0) < amount) {
        return { success:false, insufficient:true, account:acc, amount, reminder,
          message:`"${acc.name}" has ₹${(acc.balance||0).toLocaleString()} but ₹${amount.toLocaleString()} is needed for "${reminder.title}". Shortfall: ₹${(amount-(acc.balance||0)).toLocaleString()}.` };
      }
    }

    const tx = {
      user: uid,
      _id: `tx_${Date.now()}_auto`,
      createdAt: today.toISOString(),
      date: today.toISOString(),
      amount,
      merchant:     reminder.title,
      description:  `Auto-debit: ${reminder.title}`,
      category:     reminder.type==='credit_card'  ? 'Credit Card Payment'
                  : reminder.type==='rent'          ? 'Rent'
                  : reminder.type==='loan'          ? 'Loan EMI'
                  : reminder.type==='subscription'  ? 'Subscription' : 'Bills & Utilities',
      type:         'debit',
      paymentMethod: reminder.account==='cash' ? 'cash' : 'net_banking',
      bankAccountId: reminder.account!=='cash' ? reminder.account : null,
      mode:          reminder.account==='cash' ? 'cash' : 'non-cash',
      autoDebit: true,
    };

    const freshTx = load(txKey,[]);
    const newTxArr = [tx, ...freshTx];
    _setTx(newTxArr); if(txKey) save(txKey, newTxArr);

    if (tx.bankAccountId) {
      const freshAcc = load(accKey,[]);
      const updAcc = freshAcc.map(a => a?.id===tx.bankAccountId
        ? { ...a, balance: (typeof a.balance==='number'?a.balance:0) - amount } : a);
      _setAcc(updAcc); if(accKey) save(accKey, updAcc);
    }

    const freshRem = load(remKey,[]);
    const updRem = freshRem.map(r => r.id===reminder.id
      ? { ...r, completed: reminder.frequency!=='once', lastPaid:today.toISOString() } : r);
    _setRem(updRem); if(remKey) save(remKey, updRem);

    return { success:true, tx };
  };

  const resetAllData = () => {
    if (!uid) return;
    setTransactions([]); setBankAccounts([]); setReminders([]);
    try { localStorage.setItem(`settings_${uid}`, JSON.stringify({})); } catch {}
  };

  return {
    transactions, bankAccounts, reminders,
    setTransactions, setBankAccounts, setReminders,
    _setTx, _setAcc, _setRem, // raw setters for backend sync
    addTransaction, updateTransaction, deleteTransaction,
    addBankAccount, updateBankAccount, deleteBankAccount,
    addReminder, updateReminder, deleteReminder,
    autoDebitReminder, resetAllData,
  };
}

// ─── Error Boundary ───────────────────────────────────────────────────────────
class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError:false, error:null }; }
  static getDerivedStateFromError(e) { return { hasError:true, error:e }; }
  componentDidCatch(e,i) { console.error('EB:',e,i); }
  render() {
    if (this.state.hasError) return (
      <div style={{padding:'2rem',color:'red',background:'#1a0000',borderRadius:'8px',margin:'1rem'}}>
        <h2>⚠️ Something went wrong</h2>
        <pre style={{background:'#330000',padding:'1rem',borderRadius:'4px',color:'#ff6b6b',overflow:'auto'}}>
          {this.state.error?.message}
        </pre>
        <button onClick={()=>window.location.reload()}
          style={{marginTop:'1rem',padding:'0.5rem 1rem',background:'#dc3545',color:'white',border:'none',borderRadius:'4px',cursor:'pointer'}}>
          Reload
        </button>
      </div>
    );
    return this.props.children;
  }
}

// ─── Component imports ────────────────────────────────────────────────────────
import SummaryCards       from './components/SummaryCards';
import AddTransaction     from './components/AddTransaction';
import AddCreditTransaction from './components/AddCreditTransaction';
import AddCashTransaction from './components/AddCashTransaction';
import Analytics          from './components/Analytics';
import BankAccountManager from './components/BankAccountManager';
import PaymentReminders   from './components/PaymentReminders';
import PredictionCard     from './components/PredictionCard';
import VoiceAssistant     from './components/VoiceAssistant';
import AIChatAssistant    from './components/AIChatAssistant';
import TransactionSections from './components/TransactionSections';
import SavingPlanner      from './components/SavingPlanner';
import Reports            from './components/Reports';
import SettingsComponent  from './components/Settings';
import WhatIfSimulator    from './components/WhatIfSimulator';
import SmartOverspendingAlerts from './components/SmartOverspendingAlerts';
import SMSExpenseExtractor from './components/SMSExpenseExtractor';
import EditTransactionModal from './components/EditTransactionModal';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { NotificationProvider } from './contexts/NotificationContext';
import NotificationDisplay from './components/NotificationDisplay';
import WeeklyReportScheduler from './components/WeeklyReportScheduler';
import DailyExpenseReminder  from './components/DailyExpenseReminder';
import FamilyBudgetManager   from './components/FamilyBudgetManager';
import MinimalAuth     from './components/MinimalAuth';
import WelcomeScreen   from './components/WelcomeScreen';
import DashboardNew    from './pages/DashboardNew';
import AnalyticsPage   from './pages/AnalyticsPage';
import AIInsightsPage  from './pages/AIInsightsPage';
import SavingGoalsPage from './pages/SavingGoalsPage';
import FamilyBudgetPage from './pages/FamilyBudgetPage';
import SMSExtractorPage from './pages/SMSExtractorPage';
import WhatIfPage      from './pages/WhatIfPage';
import ReportsPage     from './pages/ReportsPage';
import BankAccountsPage from './pages/BankAccountsPage';

// ─── Animated Background ──────────────────────────────────────────────────────
const AnimatedBackground = () => {
  const particles = useMemo(() => Array.from({length:20},(_,i)=>({
    id:i, width:Math.floor(Math.random()*100)+20, height:Math.floor(Math.random()*100)+20,
    left:Math.random()*100, top:Math.random()*100,
    xMove:Math.random()*100-50, duration:Math.random()*10+10, delay:Math.random()*5,
  })),[]);
  return (
    <div className="fixed inset-0 overflow-hidden -z-10">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-indigo-900 to-black"/>
      {particles.map(p=>(
        <motion.div key={p.id} className="absolute rounded-full bg-blue-400/20"
          style={{width:p.width,height:p.height,left:`${p.left}%`,top:`${p.top}%`}}
          animate={{y:[0,-100,0],x:[0,p.xMove,0],opacity:[0.2,0.5,0.2]}}
          transition={{duration:p.duration,repeat:Infinity,ease:'easeInOut',delay:p.delay}}/>
      ))}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-blue-500/10 to-transparent"/>
    </div>
  );
};

// ─── Navbar (no nav items) ────────────────────────────────────────────────────
const Navbar = ({ user, onLogout }) => {
  const [open, setOpen] = useState(false);
  const { isDarkMode, toggleTheme } = useTheme();
  return (
    <motion.header className="w-full py-4 px-4 md:px-6 bg-gradient-to-r from-blue-900/80 to-indigo-900/80 backdrop-blur-lg border-b border-blue-500/20"
      initial={{y:-100}} animate={{y:0}} transition={{duration:0.5}}>
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <motion.div className="flex items-center space-x-3" whileHover={{scale:1.03}}>
          <div className="p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg animate-classy-pulse">
            <Wallet className="h-6 w-6 text-white"/>
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-black bg-gradient-to-r from-blue-300 via-indigo-300 to-purple-300 bg-clip-text text-transparent">TRIKIA</h1>
            <p className="text-xs text-gray-400">AI Budget Tracker</p>
            {user && <motion.p className="text-sm text-gray-300 italic" initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.3}}>
              Welcome, <span className="font-semibold text-white">{user.name}</span>
            </motion.p>}
          </div>
        </motion.div>

        <div className="hidden md:flex items-center space-x-3">
          <button onClick={toggleTheme} className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition-all">
            {isDarkMode ? <Sun className="h-5 w-5 text-yellow-400"/> : <Moon className="h-5 w-5 text-gray-300"/>}
          </button>
          {user && (
            <motion.div className="flex items-center space-x-2 px-3 py-2 bg-green-500/20 border border-green-500/30 rounded-lg"
              initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} whileHover={{scale:1.05}}>
              <div className="p-1.5 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg">
                <User className="h-4 w-4 text-white"/>
              </div>
              <span className="text-white font-semibold text-sm">{user.name}</span>
            </motion.div>
          )}
          {user && (
            <motion.button onClick={onLogout}
              className="flex px-4 py-2 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-lg hover:from-red-500 hover:to-red-600 items-center space-x-2 shadow-lg"
              whileHover={{scale:1.05}} whileTap={{scale:0.95}}>
              <LogOut className="h-4 w-4"/>
              <span className="font-medium">Logout</span>
            </motion.button>
          )}
        </div>

        <button className="md:hidden p-2 text-gray-300 hover:text-white hover:bg-white/10 rounded-lg"
          onClick={()=>setOpen(!open)}>
          {open ? <X className="h-6 w-6"/> : <Menu className="h-6 w-6"/>}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div className="md:hidden mt-4 py-4 border-t border-blue-500/20"
            initial={{opacity:0,height:0}} animate={{opacity:1,height:'auto'}} exit={{opacity:0,height:0}}>
            <div className="flex flex-col space-y-3">
              {user && <div className="px-4 py-3 bg-blue-500/20 border border-blue-500/30 rounded-lg">
                <p className="text-blue-200 text-sm">👋 Welcome back,</p>
                <p className="text-white font-bold text-lg">{user.name}</p>
              </div>}
              <button onClick={()=>{toggleTheme();setOpen(false);}}
                className="px-4 py-3 bg-white/10 text-white rounded-lg flex items-center space-x-2">
                {isDarkMode ? <Sun className="h-4 w-4 text-yellow-400"/> : <Moon className="h-4 w-4 text-gray-300"/>}
                <span>Switch Theme</span>
              </button>
              {user && <button onClick={()=>{onLogout();setOpen(false);}}
                className="px-4 py-3 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-lg flex items-center space-x-2">
                <LogOut className="h-4 w-4"/>
                <span>Logout</span>
              </button>}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
};

// ─── Transactions Page (uses shared state) ────────────────────────────────────
const TransactionsPageInternal = ({ transactions, bankAccounts, onAdd, onUpdate, onDelete }) => {
  const navigate = useNavigate();
  const [tab, setTab]     = useState('expense');
  const [editTx, setEditTx] = useState(null);
  const [showEdit, setShowEdit] = useState(false);
  const safe = Array.isArray(transactions) ? transactions : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4 mb-2">
        <button onClick={()=>navigate('/')} className="p-3 bg-white/10 border border-white/20 rounded-xl hover:bg-white/20">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7"/>
          </svg>
        </button>
        <h1 className="text-3xl font-bold text-white">Transactions</h1>
      </div>

      <div className="flex space-x-2 bg-white/10 p-2 rounded-xl border border-white/20">
        {[['expense','💸 Expense','from-red-500 to-pink-500'],
          ['credit','💳 Income','from-green-500 to-emerald-500'],
          ['cash','💵 Cash','from-blue-500 to-cyan-500']].map(([k,l,g])=>(
          <button key={k} onClick={()=>setTab(k)}
            className={`flex-1 px-4 py-3 rounded-lg font-semibold transition-all ${tab===k?`bg-gradient-to-r ${g} text-white`:'text-gray-300 hover:text-white'}`}>
            {l}
          </button>
        ))}
      </div>

      <div>
        {tab==='expense' && <AddTransaction onAdd={onAdd} accounts={bankAccounts}/>}
        {tab==='credit'  && <AddCreditTransaction onAdd={onAdd} accounts={bankAccounts}/>}
        {tab==='cash'    && <AddCashTransaction onAdd={onAdd} accounts={bankAccounts}/>}
      </div>

      <div className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl">
        <h2 className="text-xl font-bold text-white mb-4">All Transactions ({safe.length})</h2>
        {safe.length === 0
          ? <p className="text-gray-400 text-center py-8">No transactions yet.</p>
          : <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
              {safe.map(tx=>(
                <div key={tx._id} className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10 hover:bg-white/10 transition-all">
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-medium truncate">{tx.merchant||tx.description||'Transaction'}</p>
                    <p className="text-gray-400 text-sm">{tx.category} · {tx.paymentMethod} · {new Date(tx.date||tx.createdAt).toLocaleDateString()}</p>
                    {tx.autoDebit && <span className="text-xs bg-orange-500/20 text-orange-300 px-2 py-0.5 rounded-full">Auto-debit</span>}
                  </div>
                  <div className="flex items-center space-x-3 ml-3">
                    <span className={`font-bold text-lg ${tx.type==='credit'?'text-green-400':'text-red-400'}`}>
                      {tx.type==='credit'?'+':'-'}₹{(tx.amount||0).toLocaleString()}
                    </span>
                    <button onClick={()=>{setEditTx(tx);setShowEdit(true);}}
                      className="text-xs px-3 py-1.5 bg-blue-500/20 hover:bg-blue-500/40 text-blue-300 rounded-lg">Edit</button>
                    <button onClick={()=>onDelete(tx._id)}
                      className="text-xs px-3 py-1.5 bg-red-500/20 hover:bg-red-500/40 text-red-300 rounded-lg">Del</button>
                  </div>
                </div>
              ))}
            </div>}
      </div>

      <EditTransactionModal transaction={editTx} isOpen={showEdit}
        onClose={()=>setShowEdit(false)} onSave={onUpdate} onDelete={onDelete} accounts={bankAccounts}/>
    </div>
  );
};

// ─── Payment Reminders Page (uses shared state) ───────────────────────────────
const PaymentRemindersPageInternal = ({ user, bankAccounts, reminders, onAdd, onUpdate, onDelete, onAutoDebit, onAddTransaction }) => {
  const navigate = useNavigate();
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <button onClick={()=>navigate('/')} className="p-3 bg-white/10 border border-white/20 rounded-xl hover:bg-white/20">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7"/>
          </svg>
        </button>
        <h1 className="text-3xl font-bold text-white">Payment Reminders</h1>
      </div>
      <PaymentReminders user={user} bankAccounts={bankAccounts} reminders={reminders}
        onAddReminder={onAdd} onUpdateReminder={onUpdate} onDeleteReminder={onDelete}
        onAutoDebit={onAutoDebit} onAddTransaction={onAddTransaction}/>
    </div>
  );
};

// ─── Main App ─────────────────────────────────────────────────────────────────
function App() {
  return (
    <ErrorBoundary>
      <NotificationProvider>
        <ThemeProvider>
          <Router><AppContent/></Router>
        </ThemeProvider>
        <NotificationDisplay/>
      </NotificationProvider>
    </ErrorBoundary>
  );
}

// ─── AppContent ───────────────────────────────────────────────────────────────
function AppContent() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser]                       = useState(null);
  const [isVoiceListening, setIsVoiceListening] = useState(false);
  const [activeTransactionTab, setActiveTransactionTab] = useState('expense');
  const [showEditModal, setShowEditModal]     = useState(false);
  const [selectedTx, setSelectedTx]          = useState(null);
  const [isChatVisible, setIsChatVisible]    = useState(false);
  const [showWelcome, setShowWelcome]        = useState(true);
  const [showTermsModal, setShowTermsModal]  = useState(false);
  const [termsAccepted, setTermsAccepted]    = useState(false);
  const [toast, setToast]                    = useState({ show:false, message:'', type:'success' });
  const { isDarkMode } = useTheme();

  // Central data — single source of truth for the whole app
  const data = useAppData(user);
  const { transactions, bankAccounts, reminders, goals,
          addTransaction, updateTransaction, deleteTransaction,
          addBankAccount, updateBankAccount, deleteBankAccount,
          addReminder, updateReminder, deleteReminder,
          autoDebitReminder, resetAllData, setTransactions, setBankAccounts, setGoals,
          _setTx, _setAcc, _setRem, _setGoal } = data;

  // Expose addTransaction globally for PaymentReminders "Top Up" button
  useEffect(() => {
    window._appAddTransaction = addTransaction;
    return () => { delete window._appAddTransaction; };
  }, [addTransaction]);

  // Toast helpers
  useEffect(() => {
    if (!toast.show) return;
    const t = setTimeout(() => setToast(p=>({...p,show:false})), 4000);
    return () => clearTimeout(t);
  }, [toast.show]);

  const showToast = (message, type='success') => setToast({ show:true, message, type });

  // Load user settings
  const loadUserSettings = () => {
    if (!user) return {};
    try { return JSON.parse(localStorage.getItem(`settings_${user.id}`) || '{}'); } catch { return {}; }
  };

  // ── Session restore + load all data from backend ──
  useEffect(() => {
    const storedAuth = localStorage.getItem('isAuthenticated');
    const storedUser = localStorage.getItem('currentUser');
    if (storedAuth==='true' && storedUser) {
      try {
        const ud = JSON.parse(storedUser);
        setIsAuthenticated(true); setUser(ud); setShowWelcome(false);
        if (localStorage.getItem(`terms_accepted_${ud.id}`)) {
          setTermsAccepted(true);
          // Load all data from backend (with localStorage fallback)
          loadAllUserData(ud.id).then(data => {
            if (data) {
              if (Array.isArray(data.transactions)  && data.transactions.length  > 0) _setTx(data.transactions);
              if (Array.isArray(data.bankAccounts)   && data.bankAccounts.length  > 0) _setAcc(data.bankAccounts);
              if (Array.isArray(data.reminders)      && data.reminders.length     > 0) _setRem(data.reminders);
              if (Array.isArray(data.goals)          && data.goals.length         > 0) _setGoal(data.goals);
            }
          }).catch(console.error);
        } else {
          setShowTermsModal(true);
        }
      } catch {
        localStorage.removeItem('isAuthenticated'); localStorage.removeItem('currentUser');
        setShowWelcome(true);
      }
    } else if (!storedAuth && !storedUser) {
      setShowWelcome(true);
    } else {
      setShowWelcome(false);
    }
  }, []);

  // ── Auth handlers ──
  const handleAuthSuccess = (ud) => {
    setIsAuthenticated(true); setUser(ud); setShowWelcome(false);
    if (!localStorage.getItem(`terms_accepted_${ud.id}`)) {
      setShowTermsModal(true);
    } else {
      setTermsAccepted(true);
      // Load all data from backend on login
      loadAllUserData(ud.id).then(data => {
        if (data) {
          if (Array.isArray(data.transactions)  && data.transactions.length  > 0) _setTx(data.transactions);
          if (Array.isArray(data.bankAccounts)   && data.bankAccounts.length  > 0) _setAcc(data.bankAccounts);
          if (Array.isArray(data.reminders)      && data.reminders.length     > 0) _setRem(data.reminders);
          if (Array.isArray(data.goals)          && data.goals.length         > 0) _setGoal(data.goals);
        }
      }).catch(console.error);
    }
  };

  const handleAcceptTerms = () => {
    if (!user?.id) return;
    localStorage.setItem(`terms_accepted_${user.id}`, 'true');
    setTermsAccepted(true); setShowTermsModal(false);
    showToast("✅ Welcome! Let's manage your finances smartly!");
    // Push any existing localStorage data to backend
    const uid = user.id;
    loadAllUserData(uid).then(data => {
      if (data) {
        if (Array.isArray(data.transactions)  && data.transactions.length  > 0) _setTx(data.transactions);
        if (Array.isArray(data.bankAccounts)   && data.bankAccounts.length  > 0) _setAcc(data.bankAccounts);
        if (Array.isArray(data.reminders)      && data.reminders.length     > 0) _setRem(data.reminders);
        if (Array.isArray(data.goals)          && data.goals.length         > 0) _setGoal(data.goals);
      }
    }).catch(console.error);
  };

  const handleRejectTerms = () => {
    localStorage.removeItem('isAuthenticated'); localStorage.removeItem('currentUser'); localStorage.removeItem('token');
    setIsAuthenticated(false); setUser(null); setShowWelcome(true); setShowTermsModal(false);
    showToast('You must accept the terms to continue.', 'warning');
  };

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated'); localStorage.removeItem('currentUser');
    localStorage.removeItem('token'); localStorage.removeItem('loginTimestamp');
    setIsAuthenticated(false); setUser(null); setShowWelcome(true);
  };

  // ── Wrapped add (shows toast + persists to backend) ──
  const handleAddTransaction = (newTx) => {
    const tx = addTransaction(newTx);
    if (!tx) { showToast('❌ Failed to add transaction', 'error'); return; }
    showToast(`✅ ${tx.type==='credit'?'Income':'Expense'} of ₹${tx.amount.toLocaleString()} added!`);
    // Fire-and-forget to backend (localStorage is already updated by addTransaction)
    if (user?.id) addTransactionAPI({ ...tx, user: user.id }).catch(console.error);
    return tx;
  };

  const handleUpdateTransaction = (upd) => {
    updateTransaction(upd);
    showToast('✅ Transaction updated!');
    if (user?.id) updateTransactionAPI(upd).catch(console.error);
  };

  const handleDeleteTransaction = (id) => {
    deleteTransaction(id);
    showToast('✅ Transaction deleted!');
    if (user?.id) deleteTransactionAPI(id).catch(console.error);
  };

  // ── Auto-debit (called by PaymentReminders) ──
  const handleAutoDebit = (reminder) => {
    const result = autoDebitReminder(reminder);
    if (result.success) {
      showToast(`✅ Auto-debited ₹${reminder.amount.toLocaleString()} for "${reminder.title}"`);
      // Sync tx and updated reminder to backend
      if (user?.id && result.tx) addTransactionAPI({ ...result.tx, user: user.id }).catch(console.error);
      if (user?.id) updatePaymentReminderAPI({ ...reminder, completed: true, lastPaid: new Date().toISOString(), user_id: user.id }).catch(console.error);
    } else if (result.insufficient) {
      showToast(`⚠️ Insufficient balance for "${reminder.title}"`, 'warning');
    }
    return result;
  };

  // BankAccountManager expects onUpdateAccounts(array) — bridge to our hook + backend
  const handleUpdateAccounts = (newAccounts) => {
    const safe = Array.isArray(newAccounts) ? newAccounts : [];
    setBankAccounts(safe);
    // Sync full accounts array to backend (bulk upsert)
    if (user?.id) {
      import('./utils/api').then(({ syncBankAccounts }) => {
        syncBankAccounts(user.id, safe).catch(console.error);
      });
    }
  };

  // ── Screens ──
  if (!isAuthenticated && showWelcome)
    return (<><WelcomeScreen onComplete={()=>setShowWelcome(false)} isAuthenticated={false}/><AnimatedBackground/></>);
  if (!isAuthenticated)
    return <MinimalAuth onAuthSuccess={handleAuthSuccess}/>;

  const safe   = Array.isArray(transactions) ? transactions : [];
  const userSettings = loadUserSettings();

  return (
    <div className="min-h-screen relative classy-container">
      <AnimatedBackground/>
      <div className="relative z-10">
        <Navbar user={user} onLogout={handleLogout}/>

        <AnimatePresence>
          {toast.show && (
            <motion.div className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-6 py-3 rounded-xl shadow-lg ${
              toast.type==='success'?'bg-green-600':toast.type==='error'?'bg-red-600':'bg-yellow-600'}`}
              initial={{opacity:0,y:-20}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-20}}>
              <p className="text-white font-medium">{toast.message}</p>
            </motion.div>
          )}
        </AnimatePresence>

        <main className="max-w-7xl mx-auto p-6">
          <Routes>

            {/* ── Dashboard ── */}
            <Route path="/" element={
              <>
                <WeeklyReportScheduler user={user} transactions={safe} settings={userSettings.notifications}/>
                <DailyExpenseReminder  user={user} transactions={safe} settings={userSettings.notifications}/>
                <DashboardNew transactions={safe} user={user}/>
              </>
            }/>

            {/* ── Transactions ── */}
            <Route path="/transactions" element={
              <TransactionsPageInternal
                transactions={safe} bankAccounts={bankAccounts}
                onAdd={handleAddTransaction} onUpdate={handleUpdateTransaction} onDelete={handleDeleteTransaction}/>
            }/>

            {/* ── Analytics (receives live transactions) ── */}
            <Route path="/analytics" element={<AnalyticsPage transactions={safe} bankAccounts={bankAccounts}/>}/>

            {/* ── AI Insights ── */}
            <Route path="/ai-insights" element={<AIInsightsPage transactions={safe} user={user}/>}/>

            {/* ── Saving Goals ── */}
            <Route path="/saving-goals" element={
              <SavingGoalsPage 
                transactions={safe} 
                user={user}
                goals={goals}
                setGoals={setGoals}
              />
            }/>

            {/* ── Payment Reminders (fully synced) ── */}
            <Route path="/payment-reminders" element={
              <PaymentRemindersPageInternal
                user={user} bankAccounts={bankAccounts} reminders={reminders}
                onAdd={(r) => {
                  addReminder(r);
                  if (user?.id) addPaymentReminderAPI(user.id, r).catch(console.error);
                }}
                onUpdate={(id, changes) => {
                  updateReminder(id, changes);
                  if (user?.id) updatePaymentReminderAPI({ id, ...changes, user_id: user.id }).catch(console.error);
                }}
                onDelete={(id) => {
                  deleteReminder(id);
                  if (user?.id) deletePaymentReminderAPI(id).catch(console.error);
                }}
                onAutoDebit={handleAutoDebit} onAddTransaction={handleAddTransaction}/>
            }/>

            {/* ── Family Budget ── */}
            <Route path="/family-budget" element={<FamilyBudgetPage user={user} transactions={safe}/>}/>

            {/* ── SMS Extractor ── */}
            <Route path="/sms-extractor" element={<SMSExtractorPage onAddTransaction={handleAddTransaction}/>}/>

            {/* ── What-If ── */}
            <Route path="/what-if" element={<WhatIfPage transactions={safe}/>}/>

            {/* ── Reports (live data) ── */}
            <Route path="/reports" element={<ReportsPage transactions={safe}/>}/>

            {/* ── Bank Accounts ── */}
            <Route path="/bank-accounts" element={
              <BankAccountsPage
                user={user}
                bankAccounts={bankAccounts}
                transactions={safe}
                onUpdateAccounts={setBankAccounts}
              />
            }/>

            {/* ── Settings ── */}
            <Route path="/settings" element={
              <SettingsComponent
                currentUser={user}
                transactions={safe}
                setTransactions={(arr) => { setTransactions(Array.isArray(arr)?arr:[]); }}
                setGoals={()=>{}}
                setBankAccounts={(arr) => { setBankAccounts(Array.isArray(arr)?arr:[]); }}
              />
            }/>

          </Routes>

          {/* ── Floating widgets ── */}
          <VoiceAssistant
            onTransactionDetected={handleAddTransaction}
            isListening={isVoiceListening} setIsListening={setIsVoiceListening}
            bankAccounts={bankAccounts} setActiveTab={()=>{}}/>

          <AIChatAssistant
            transactions={safe} bankAccounts={bankAccounts}
            isVisible={isChatVisible} setIsVisible={setIsChatVisible}/>

          <EditTransactionModal
            transaction={selectedTx} isOpen={showEditModal}
            onClose={()=>setShowEditModal(false)}
            onSave={handleUpdateTransaction} onDelete={handleDeleteTransaction}
            accounts={bankAccounts}/>

          {/* ── Terms Modal ── */}
          <AnimatePresence>
            {showTermsModal && (
              <motion.div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50"
                initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={e=>e.stopPropagation()}>
                <motion.div className="bg-gradient-to-br from-slate-900/95 to-slate-800/95 backdrop-blur-xl border border-blue-500/30 rounded-2xl p-8 w-full max-w-3xl shadow-2xl max-h-[90vh] overflow-y-auto"
                  initial={{scale:0.9,y:-20}} animate={{scale:1,y:0}} exit={{scale:0.9,y:-20}} onClick={e=>e.stopPropagation()}>

                  <div className="flex items-center space-x-4 mb-6 pb-5 border-b border-white/10">
                    <div className="p-3.5 bg-gradient-to-br from-blue-500 via-purple-500 to-indigo-600 rounded-xl">
                      <Shield className="h-9 w-9 text-white"/>
                    </div>
                    <div>
                      <h2 className="text-3xl font-black bg-gradient-to-r from-blue-300 via-purple-300 to-pink-300 bg-clip-text text-transparent">Welcome to TRIKIA</h2>
                      <p className="text-white font-semibold mt-1">AI Budget Tracker</p>
                    </div>
                  </div>

                  <div className="space-y-4 mb-8">
                    {[
                      { icon:<Lock className="h-6 w-6 text-blue-400 flex-shrink-0 mt-1"/>, bg:'bg-blue-500/10 border-blue-400/20',
                        title:'🔒 Local Storage Only', text:'All your data stays on your device. Nothing is uploaded to external servers.' },
                      { icon:<Shield className="h-6 w-6 text-green-400 flex-shrink-0 mt-1"/>, bg:'bg-green-500/10 border-green-400/20',
                        title:'🛡️ Your Privacy Matters', text:'No bank details or sensitive financial information are collected.' },
                      { icon:<User className="h-6 w-6 text-purple-400 flex-shrink-0 mt-1"/>, bg:'bg-purple-500/10 border-purple-400/20',
                        title:'👤 You\'re in Control', text:'None of your data can be accessed by anyone other than you.' },
                      { icon:<Brain className="h-6 w-6 text-orange-400 flex-shrink-0 mt-1"/>, bg:'bg-orange-500/10 border-orange-400/20',
                        title:'🤖 Smart Assistance', text:'AI chat and voice assistant work entirely with your local data — no external sharing.' },
                      { icon:<Eye className="h-6 w-6 text-cyan-400 flex-shrink-0 mt-1"/>, bg:'bg-cyan-500/10 border-cyan-400/20',
                        title:'✅ Transparency First', text:'No hidden agendas, no data mining. You are the sole owner.' },
                    ].map((item,i)=>(
                      <div key={i} className={`flex items-start space-x-4 ${item.bg} border rounded-xl p-4`}>
                        {item.icon}
                        <div>
                          <h3 className="text-lg font-bold text-white mb-1">{item.title}</h3>
                          <p className="text-gray-300 text-sm">{item.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10 border border-white/20 rounded-2xl p-5 mb-6">
                    <h3 className="text-lg font-bold text-white mb-3 flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-400 mr-2"/> Key Benefits
                    </h3>
                    <ul className="space-y-2">
                      {['100% Private & Secure — data stays on your device',
                        'AI-Powered Insights — smart help without privacy risk',
                        'Complete sync — every change reflected everywhere instantly',
                        'Auto-debit payments — never miss a payment date',
                        'Free Forever — no hidden costs'].map((b,i)=>(
                        <li key={i} className="flex items-start text-gray-200 text-sm">
                          <span className="text-green-400 mr-2">✓</span>{b}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-6">
                    <label className="flex items-start space-x-3 cursor-pointer">
                      <input type="checkbox" checked={termsAccepted} onChange={e=>setTermsAccepted(e.target.checked)}
                        className="w-5 h-5 text-blue-600 bg-gray-700 border-gray-500 rounded mt-1"/>
                      <span className="text-sm text-gray-300">
                        By continuing, I acknowledge that all data is stored locally on my device for personal budget tracking only.
                      </span>
                    </label>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4">
                    <button onClick={handleRejectTerms} className="flex-1 px-8 py-4 bg-gray-700 hover:bg-gray-600 text-white rounded-xl font-bold transition-all">Exit App</button>
                    <button onClick={handleAcceptTerms} disabled={!termsAccepted}
                      className={`flex-1 px-8 py-4 rounded-xl font-bold transition-all ${
                        termsAccepted ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white' : 'bg-gray-700 text-gray-500 cursor-not-allowed opacity-50'}`}>
                      Accept & Continue ✨
                    </button>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

export default App;