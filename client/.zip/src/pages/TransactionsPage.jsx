import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Receipt, Plus, Filter, Search } from 'lucide-react';
import AnimatedBackground from '../components/AnimatedBackground';
import AddTransaction from '../components/AddTransaction';
import AddCashTransaction from '../components/AddCashTransaction';
import AddCreditTransaction from '../components/AddCreditTransaction';
import Transactions from '../components/Transactions';
import EditableTransactionList from '../components/EditableTransactionList';
import { getTransactions } from '../utils/api';

const TransactionsPage = () => {
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('expense'); // 'expense', 'credit', 'cash'

  async function load() {
    setLoading(true);
    try {
      const data = await getTransactions();
      const convertedData = data.map(tx => ({
        ...tx,
        amount: tx.currency === 'USD' ? tx.amount * 83 : tx.amount,
        currency: 'INR'
      }));
      setTransactions(Array.isArray(convertedData) ? convertedData : []);
    } catch (err) {
      console.error(err);
    } finally { 
      setLoading(false); 
    }
  }

  useEffect(() => { 
    load(); 
  }, []);

  function handleAdd(tx) {
    const item = tx && tx.transaction ? tx.transaction : tx;
    const transactionWithINR = {
      ...item,
      amount: item.currency === 'USD' ? item.amount * 83 : item.amount,
      currency: 'INR'
    };
    setTransactions(prev => [transactionWithINR, ...prev]);
  }

  return (
    <div className="min-h-screen relative">
      <AnimatedBackground />
      
      <div className="relative z-10">
        <motion.main 
          className="max-w-7xl mx-auto p-4 md:p-6"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Header */}
          <div className="flex items-center space-x-4 mb-6">
            <button
              onClick={() => navigate('/')}
              className="p-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl hover:bg-white/20 transition-all"
            >
              <ArrowLeft className="w-6 h-6 text-white" />
            </button>
            <div>
              <h1 className="text-3xl font-bold text-white flex items-center space-x-3">
                <Receipt className="w-8 h-8 text-blue-400" />
                <span>Transactions</span>
              </h1>
              <p className="text-gray-400 mt-1">Manage all your income and expenses</p>
            </div>
          </div>

          {/* Tab Selection */}
          <div className="flex space-x-2 mb-6 bg-white/10 backdrop-blur-xl p-2 rounded-xl border border-white/20">
            <button
              onClick={() => setActiveTab('expense')}
              className={`flex-1 px-4 py-3 rounded-lg font-semibold transition-all ${
                activeTab === 'expense' 
                  ? 'bg-gradient-to-r from-red-500 to-pink-500 text-white' 
                  : 'text-gray-300 hover:text-white'
              }`}
            >
              💸 Expense
            </button>
            <button
              onClick={() => setActiveTab('credit')}
              className={`flex-1 px-4 py-3 rounded-lg font-semibold transition-all ${
                activeTab === 'credit' 
                  ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white' 
                  : 'text-gray-300 hover:text-white'
              }`}
            >
              💳 Credit
            </button>
            <button
              onClick={() => setActiveTab('cash')}
              className={`flex-1 px-4 py-3 rounded-lg font-semibold transition-all ${
                activeTab === 'cash' 
                  ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white' 
                  : 'text-gray-300 hover:text-white'
              }`}
            >
              💵 Cash
            </button>
          </div>

          {/* Add Transaction Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-6"
          >
            {activeTab === 'expense' && (
              <AddTransaction onAdd={handleAdd} currency="INR" currencySymbol="₹" transactions={transactions} />
            )}
            {activeTab === 'credit' && (
              <AddCreditTransaction onAdd={handleAdd} currency="INR" currencySymbol="₹" />
            )}
            {activeTab === 'cash' && (
              <AddCashTransaction onAdd={handleAdd} currency="INR" currencySymbol="₹" />
            )}
          </motion.div>

          {/* Transaction List */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <EditableTransactionList 
              transactions={transactions}
              onUpdate={setTransactions}
            />
          </motion.div>
        </motion.main>
      </div>
    </div>
  );
};

export default TransactionsPage;
